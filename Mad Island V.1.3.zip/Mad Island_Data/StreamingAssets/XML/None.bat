@rem Mad Island no-mosaic marker file. The game checks only whether this file exists.
